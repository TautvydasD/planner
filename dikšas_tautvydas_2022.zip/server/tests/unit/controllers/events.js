// import {
//   getEvents,
//   // createEvent,
//   // editEvents,
//   // removeEvents,
// } from '../../src/controllers/events';

// describe('Event Getters', () => {
//   it('returns all data', async () => {
//     axios.get = jest.fn();
//     await getEvents
//   });
// });
